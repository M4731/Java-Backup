package main;

public class Example3 {

    public static void main(String[] args) {
        Square s1 = new Square();

        s1.area = 10;
        s1.side = 10;

        Circle c1 = new Circle();

        c1.area = ":)";
        c1.radius = 10;
        c1.abc();
    }
}
