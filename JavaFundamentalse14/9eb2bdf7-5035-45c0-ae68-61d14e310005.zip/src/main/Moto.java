package main;

public class Moto extends Bicycle {

    int engine;
    int wheel1;
    int wheel2;


}
