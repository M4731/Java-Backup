package main;

public class Example1 {

    public static void main(String[] args) {
        Cat c1 = new Cat();

        c1.setName("Tom");
        c1.setAge(10);

        System.out.println(c1.getName());
    }
}
