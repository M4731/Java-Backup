package main;

public class Circle extends Shape { // is-A

    /*
    - add new fields
    - add new behaviour
    - change fields -> hiding fields
    - change behaviour -> overriding
     */
    int radius;
    String area; // super

    void abc() {

    }
}
