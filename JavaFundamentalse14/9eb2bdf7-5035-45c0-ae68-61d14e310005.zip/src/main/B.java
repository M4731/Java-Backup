package main;

public class B extends A {


}
