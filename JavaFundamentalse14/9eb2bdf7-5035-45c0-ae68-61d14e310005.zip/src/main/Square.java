package main;

public class Square extends Shape {

    double side;
}
