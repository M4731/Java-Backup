package main;

public class Bicycle {

    String wheel1;
    String wheel2;
}
