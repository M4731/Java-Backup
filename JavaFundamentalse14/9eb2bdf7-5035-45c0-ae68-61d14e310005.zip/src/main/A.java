package main;

public class A {

    int x;
    private int y;

    void m() {
        System.out.println(":)");
    }
}
