package main;

public class Shape {

    double area;
}
